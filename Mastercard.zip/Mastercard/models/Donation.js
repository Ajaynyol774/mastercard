// models/Donation.js
const mongoose = require('mongoose');

const DonationSchema = new mongoose.Schema({
  amount: {
    type: Number,
    required: true,
  },
  campaign: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Campaign',
    required: true,
  },
  donator: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    // Donations can be anonymous, so this is not strictly required
  },
  donatorName: { // For anonymous or non-logged-in users
    type: String,
    required: true,
  },
  donatorEmail: { // For sending receipts
    type: String,
    required: true,
  },
  paymentId: { // From payment gateway
    type: String,
  },
  date: {
    type: Date,
    default: Date.now,
  },
});

module.exports = mongoose.model('Donation', DonationSchema);
