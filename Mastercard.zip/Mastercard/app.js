// src/App.js
import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Navbar from './components/layout/Navbar';
import HomePage from './pages/HomePage';
import CampaignsPage from './pages/CampaignsPage';
import CampaignDetailsPage from './pages/CampaignDetailsPage';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import DonatorDashboard from './pages/DonatorDashboard';
import AdminDashboard from './pages/AdminDashboard';
import DeveloperPage from './pages/DeveloperPage';
import PrivateRoute from './components/common/PrivateRoute';
import AuthState from './context/AuthState';
import setAuthToken from './api/axiosConfig';
import './App.css';

// Set auth token on initial load if it exists
if (localStorage.token) {
  setAuthToken(localStorage.token);
}

function App() {
  return (
    <AuthState>
      <Router>
        <Navbar />
        <main className="container mx-auto px-4 py-8">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/campaigns" element={<CampaignsPage />} />
            <Route path="/campaign/:id" element={<CampaignDetailsPage />} />
            <Route path="/login" element={<LoginPage />} />
            <Route path="/register" element={<RegisterPage />} />
            
            {/* Donator Routes */}
            <Route 
              path="/dashboard" 
              element={<PrivateRoute component={DonatorDashboard} roles={['Donator', 'Administrator']} />} 
            />

            {/* Admin Routes */}
            <Route 
              path="/admin" 
              element={<PrivateRoute component={AdminDashboard} roles={['Administrator']} />} 
            />

            {/* Developer Routes */}
            <Route 
              path="/developer" 
              element={<PrivateRoute component={DeveloperPage} roles={['Developer', 'Administrator']} />} 
            />
          </Routes>
        </main>
      </Router>
    </AuthState>
  );
}

export default App;
