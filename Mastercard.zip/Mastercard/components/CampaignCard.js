// src/components/CampaignCard.js
import React from 'react';
import { Link } from 'react-router-dom';

const CampaignCard = ({ campaign }) => {
  const { _id, title, description, goalAmount, currentAmount, endDate } = campaign;
  const progress = (currentAmount / goalAmount) * 100;

  return (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden transform hover:-translate-y-2 transition-transform duration-300">
      <div className="p-6">
        <h2 className="text-2xl font-bold mb-2 text-gray-800">{title}</h2>
        <p className="text-gray-600 mb-4">{description.substring(0, 100)}...</p>
        
        <div className="mb-4">
            <div className="flex justify-between mb-1">
                <span className="text-base font-medium text-blue-700">${currentAmount.toLocaleString()}</span>
                <span className="text-sm font-medium text-gray-500">${goalAmount.toLocaleString()}</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2.5">
                <div className="bg-blue-600 h-2.5 rounded-full" style={{ width: `${progress}%` }}></div>
            </div>
        </div>

        <div className="flex items-center justify-between text-sm text-gray-500">
            <span>Ends: {new Date(endDate).toLocaleDateString()}</span>
            <Link to={`/campaign/${_id}`} className="bg-green-500 hover:bg-green-600 text-white font-bold py-2 px-4 rounded-lg transition-colors">
                Donate Now
            </Link>
        </div>
      </div>
    </div>
  );
};

export default CampaignCard;
