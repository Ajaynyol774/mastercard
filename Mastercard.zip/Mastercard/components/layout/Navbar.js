// src/components/layout/Navbar.js
import React, { useContext } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import AuthContext from '../../context/AuthContext';

const Navbar = () => {
  const { isAuthenticated, user, logout } = useContext(AuthContext);
  const navigate = useNavigate();

  const onLogout = () => {
    logout();
    navigate('/login');
  };

  const authLinks = (
    <>
      <span className="text-white mr-4">Hello, {user?.name}</span>
      {user?.role === 'Administrator' && (
        <Link to="/admin" className="text-gray-300 hover:text-white px-3 py-2 rounded-md text-sm font-medium">Admin</Link>
      )}
      {user?.role === 'Developer' && (
        <Link to="/developer" className="text-gray-300 hover:text-white px-3 py-2 rounded-md text-sm font-medium">Developer</Link>
      )}
      <Link to="/dashboard" className="text-gray-300 hover:text-white px-3 py-2 rounded-md text-sm font-medium">Dashboard</Link>
      <button onClick={onLogout} className="bg-red-500 hover:bg-red-600 text-white px-3 py-2 rounded-md text-sm font-medium">
        Logout
      </button>
    </>
  );

  const guestLinks = (
    <>
      <Link to="/login" className="text-gray-300 hover:text-white px-3 py-2 rounded-md text-sm font-medium">Login</Link>
      <Link to="/register" className="bg-green-500 hover:bg-green-600 text-white px-3 py-2 rounded-md text-sm font-medium">Register</Link>
    </>
  );

  return (
    <nav className="bg-gray-800 shadow-lg">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex-shrink-0">
            <Link to="/" className="text-white text-2xl font-bold">NGO Donate</Link>
          </div>
          <div className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-4">
              <Link to="/campaigns" className="text-gray-300 hover:text-white px-3 py-2 rounded-md text-sm font-medium">Campaigns</Link>
              {isAuthenticated ? authLinks : guestLinks}
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
