// routes/donations.js
const express = require('express');
const router = express.Router();
const Donation = require('../models/Donation');
const Campaign = require('../models/campaign');
const { protect } = require('../middleware/authMiddleware');

// @route   POST api/donations
// @desc    Make a new donation
// @access  Public
router.post('/', async (req, res) => {
  const { amount, campaignId, donatorName, donatorEmail } = req.body;

  try {
    const campaign = await Campaign.findById(campaignId);
    if (!campaign) {
      return res.status(404).json({ message: 'Campaign not found' });
    }

    const newDonation = new Donation({
      amount,
      campaign: campaignId,
      donatorName,
      donatorEmail,
      // If user is logged in, you can add req.user.id to `donator` field
    });

    // Update campaign's current amount
    campaign.currentAmount += Number(amount);
    await campaign.save();

    const donation = await newDonation.save();
    res.json(donation);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server Error');
  }
});

// @route   GET api/donations/my-donations
// @desc    Get donations for the logged-in user
// @access  Private
router.get('/my-donations', protect, async (req, res) => {
    try {
        const donations = await Donation.find({ donator: req.user.id }).populate('campaign', ['title']);
        res.json(donations);
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server Error');
    }
});


module.exports = router;
