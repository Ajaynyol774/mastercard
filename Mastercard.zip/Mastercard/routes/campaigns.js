// routes/campaigns.js
const express = require('express');
const router = express.Router();
const Campaign = require('../models/campaign');
const { protect, authorize } = require('../middleware/authMiddleware');

// @route   GET api/campaigns
// @desc    Get all active campaigns
// @access  Public
router.get('/', async (req, res) => {
  try {
    const campaigns = await Campaign.find({ isActive: true }).sort({ createdAt: -1 });
    res.json(campaigns);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server Error');
  }
});

// @route   GET api/campaigns/:id
// @desc    Get a single campaign by ID
// @access  Public
router.get('/:id', async (req, res) => {
    try {
        const campaign = await Campaign.findById(req.params.id);
        if (!campaign) {
            return res.status(404).json({ msg: 'Campaign not found' });
        }
        res.json(campaign);
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server Error');
    }
});


// @route   POST api/campaigns
// @desc    Create a new campaign
// @access  Private (Admin only)
router.post('/', protect, authorize('Administrator'), async (req, res) => {
  const { title, description, goalAmount, endDate } = req.body;
  try {
    const newCampaign = new Campaign({
      title,
      description,
      goalAmount,
      endDate,
      creator: req.user.id,
    });

    const campaign = await newCampaign.save();
    res.json(campaign);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server Error');
  }
});

module.exports = router;
