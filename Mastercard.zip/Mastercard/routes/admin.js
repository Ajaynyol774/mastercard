// routes/admin.js
const express = require('express');
const router = express.Router();
const User = require('../models/User');
const Campaign = require('../models/campaign');
const Donation = require('../models/Donation');
const { protect, authorize } = require('../middleware/authMiddleware');

// All routes in this file are protected and for Admins only
router.use(protect, authorize('Administrator'));

// @route   GET api/admin/users
// @desc    Get all users
// @access  Private (Admin)
router.get('/users', async (req, res) => {
  try {
    const users = await User.find().select('-password');
    res.json(users);
  } catch (err) {
    res.status(500).send('Server Error');
  }
});

// @route   GET api/admin/donations
// @desc    Get all donations
// @access  Private (Admin)
router.get('/donations', async (req, res) => {
  try {
    const donations = await Donation.find()
      .populate('campaign', 'title')
      .populate('donator', 'name email')
      .sort({ date: -1 });
    res.json(donations);
  } catch (err) {
    res.status(500).send('Server Error');
  }
});

// @route   PUT api/admin/campaigns/:id
// @desc    Update a campaign
// @access  Private (Admin)
router.put('/campaigns/:id', async (req, res) => {
    const { title, description, goalAmount, endDate, isActive } = req.body;
    try {
        let campaign = await Campaign.findById(req.params.id);
        if (!campaign) return res.status(404).json({ msg: 'Campaign not found' });

        campaign.title = title || campaign.title;
        campaign.description = description || campaign.description;
        campaign.goalAmount = goalAmount || campaign.goalAmount;
        campaign.endDate = endDate || campaign.endDate;
        if (isActive !== undefined) {
            campaign.isActive = isActive;
        }

        await campaign.save();
        res.json(campaign);
    } catch (err) {
        res.status(500).send('Server Error');
    }
});


module.exports = router;
