// src/pages/CampaignsPage.js
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import CampaignCard from '../components/CampaignCard';
import Spinner from '../components/common/Spinner';

const CampaignsPage = () => {
  const [campaigns, setCampaigns] = useState([]);
  const [loading, setLoading] = useState(true);
  const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

  useEffect(() => {
    const fetchCampaigns = async () => {
      try {
        const res = await axios.get(`${API_URL}/campaigns`);
        setCampaigns(res.data);
      } catch (err) {
        console.error('Error fetching campaigns:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchCampaigns();
  }, [API_URL]);

  if (loading) {
    return <Spinner />;
  }

  return (
    <div className="container mx-auto">
      <h1 className="text-4xl font-bold text-center my-8">Our Campaigns</h1>
      {campaigns.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {campaigns.map((campaign) => (
            <CampaignCard key={campaign._id} campaign={campaign} />
          ))}
        </div>
      ) : (
        <p className="text-center text-gray-500">No active campaigns at the moment. Please check back later.</p>
      )}
    </div>
  );
};

export default CampaignsPage;
